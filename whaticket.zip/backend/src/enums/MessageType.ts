export enum MessageType {
  Generic,
  Greeting,
  Farewell,
  Feedback
}
